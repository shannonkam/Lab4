#include <stdio.h>
#include <stdlib.h>

void main()
{
	printf("Hello world!\n");
}
